from pyexpat import model
from unittest.util import _MAX_LENGTH
from django.db import models

# Create your models here.
class Meetings(models.Model):
    date = models.TextField()
    start_time = models.TextField()
    end_time = models.TextField()