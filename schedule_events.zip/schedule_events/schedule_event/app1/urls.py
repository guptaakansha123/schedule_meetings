from .views import *
from django.urls import path

urlpatterns = [
    path('schedule_meeting',schedule_meetings),
    path('get_schedules',get_schedule_on_day),
    path('reschedule_meetings',reschedule_meetings),
    path('cancel_events/<int:pk>/',cancel_events),
    path('bulk_update',bulk_update),
    path('bulk_cancel',bulk_cancel)
]