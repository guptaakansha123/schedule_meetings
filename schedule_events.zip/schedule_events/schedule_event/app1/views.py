import json
from django.http import HttpResponse, JsonResponse
from django.shortcuts import render
from python_utils import raise_exception
from .models import Meetings

# Create your views here.
def schedule_meetings(request):
    date_slot = request.GET.get("date_slot")
    date = date_slot.split(" ")[0]
    start_time, end_time = (date_slot.split(" ")[1]), date_slot.split(" ")[3]
    meeting_exists = Meetings.objects.filter(date = date, start_time = start_time, end_time = end_time)
    if meeting_exists:
        return HttpResponse("there is already another schedules meeting at the same slot")
    else:
        saved = Meetings.objects.create(date = date, start_time = start_time , end_time = end_time)
        if saved:
            return HttpResponse("Data inserted successfully")
        else:
            raise Exception("some error occured")

def get_schedule_on_day(request):
    date = request.GET.get("date")
    scheduled_meetings = list(Meetings.objects.filter(date = date).values())
    data = {
        "data":scheduled_meetings
    }
    if schedule_meetings:
        return JsonResponse(data, safe =False)
    else:
        raise Exception("some error occured")

def reschedule_meetings(request):
    dates = request.GET.get("dates")
    date_slot_1= dates.split(" to ")[0]
    date_slot_2 = dates.split(" to ")[1]
    date_1 = date_slot_1.split(" ")[0]
    date_2 = date_slot_2.split(" ")[0]
    start_time_1, end_time_1 = date_slot_1.split(" ")[1], date_slot_1.split(" ")[3]
    start_time_2, end_time_2 = date_slot_2.split(" ")[1], date_slot_2.split(" ")[3]
    meeting_exists = list(Meetings.objects.filter(date = date_2, start_time = start_time_2, end_time = end_time_2).values())
    if meeting_exists:
        return HttpResponse("there is already another schedules meeting at the same slot")
    else:
        reschedule_meeting = Meetings.objects.filter(date = date_1, start_time = start_time_1, end_time = end_time_1).update(date = date_2)
        if reschedule_meeting:
            return HttpResponse("Meeting has been successfully rescheduled")
        else:
            Meetings.objects.create(date = date_2, start_time = start_time_2 , end_time = end_time_2)
            return HttpResponse("Meeting has been successfully rescheduled")
def cancel_events(request, *args, **kwargs):
    try:
        id = kwargs['pk']
        deleted = Meetings.objects.filter(id = id).delete()
        if deleted:
            return HttpResponse("Meeting has been cancelled successfully")
        else:
            raise Exception("some error")
    except Exception as e:
        raise Exception("some error")

def bulk_cancel(request):
    deleted = Meetings.objects.all().delete()
    if deleted:
        return HttpResponse("All meetings cancelled successfully")
    else:
        raise Exception("some error")
    
def bulk_update(request):
    dates = request.GET.get("data")
    for i in dates:
        date = i.split(" ")[0]
        start_time, end_time = i.split(" ")[1], i.split(" ")[3]
        meeting_exists = Meetings.objects.filter(date = date, start_time = start_time, end_time = end_time)
        if meeting_exists:
            raise Exception("there is already another schedules meeting at the same slot")
        else:
            saved = Meetings.objects.create(date = date, start_time = start_time , end_time = end_time)
            if saved:
                return HttpResponse("Data inserted successfully")
            else:
                raise Exception("some error occured")
